/**
 * ChatWave – Frontend Application
 * Handles Socket.io connection, room management, messaging, and UI state.
 */

(() => {
  'use strict';

  // ─── State ──────────────────────────────────────────────────────────────────
  const state = {
    socket: null,
    username: '',
    currentRoom: null,
    rooms: [],
    typingUsers: new Set(),
    typingTimer: null,
    isTyping: false,
  };

  // ─── DOM Refs ────────────────────────────────────────────────────────────────
  const $ = id => document.getElementById(id);
  const el = {
    loginScreen:    $('login-screen'),
    chatScreen:     $('chat-screen'),
    usernameInput:  $('username-input'),
    roomPicker:     $('room-picker'),
    joinBtn:        $('join-btn'),
    loginError:     $('login-error'),
    roomList:       $('room-list'),
    memberList:     $('member-list'),
    memberCount:    $('member-count'),
    messages:       $('messages'),
    msgInput:       $('msg-input'),
    sendBtn:        $('send-btn'),
    typingBar:      $('typing-bar'),
    roomTitle:      $('room-title'),
    roomMeta:       $('room-meta'),
    connDot:        $('connection-indicator'),
    myAvatar:       $('my-avatar'),
    myUsername:     $('my-username'),
    logoutBtn:      $('logout-btn'),
    sidebarToggle:  $('sidebar-toggle'),
    sidebar:        document.querySelector('.sidebar'),
    newRoomBtn:     $('new-room-btn'),
    modalOverlay:   $('modal-overlay'),
    newRoomInput:   $('new-room-input'),
    modalCancel:    $('modal-cancel'),
    modalCreate:    $('modal-create'),
    modalError:     $('modal-error'),
  };

  // ─── Init ────────────────────────────────────────────────────────────────────
  async function init() {
    await loadRooms();
    bindLoginEvents();
  }

  // ─── Load rooms from API ─────────────────────────────────────────────────────
  async function loadRooms() {
    try {
      const res = await fetch('/api/rooms');
      state.rooms = await res.json();
      renderRoomPicker();
    } catch {
      el.loginError.textContent = 'Could not reach server. Is it running?';
    }
  }

  function renderRoomPicker() {
    el.roomPicker.innerHTML = '';
    state.rooms.forEach(room => {
      const div = document.createElement('div');
      div.className = 'room-option';
      div.dataset.id = room.id;
      div.innerHTML = `<span># ${room.name}</span><span class="room-count">${room.memberCount} online</span>`;
      div.addEventListener('click', () => {
        document.querySelectorAll('.room-option').forEach(d => d.classList.remove('selected'));
        div.classList.add('selected');
        state.currentRoom = room.id;
        el.joinBtn.disabled = !el.usernameInput.value.trim();
      });
      el.roomPicker.appendChild(div);
    });
  }

  // ─── Login Events ────────────────────────────────────────────────────────────
  function bindLoginEvents() {
    el.usernameInput.addEventListener('input', () => {
      el.joinBtn.disabled = !el.usernameInput.value.trim() || !state.currentRoom;
      el.loginError.textContent = '';
    });

    el.usernameInput.addEventListener('keydown', e => {
      if (e.key === 'Enter') el.joinBtn.click();
    });

    el.joinBtn.addEventListener('click', () => {
      const username = el.usernameInput.value.trim();
      if (!username) return;
      if (!state.currentRoom) { el.loginError.textContent = 'Please select a room.'; return; }
      enterChat(username, state.currentRoom);
    });
  }

  // ─── Enter Chat ──────────────────────────────────────────────────────────────
  function enterChat(username, roomId) {
    state.username = username;

    // Switch screens
    el.loginScreen.classList.remove('active');
    el.chatScreen.classList.add('active');

    // Connect socket
    state.socket = io();
    bindSocketEvents();

    // Emit join after connection
    state.socket.on('connect', () => {
      state.socket.emit('user:join', { username, roomId });
      setConnected(true);
    });

    state.socket.on('disconnect', () => setConnected(false));

    // Populate my info
    el.myUsername.textContent = username;
    renderAvatar(el.myAvatar, username);

    bindChatEvents();
    bindRoomEvents();
  }

  // ─── Socket Events ───────────────────────────────────────────────────────────
  function bindSocketEvents() {
    const s = state.socket;

    s.on('messages:history', msgs => {
      el.messages.innerHTML = '';
      msgs.forEach(appendMessage);
      scrollToBottom();
    });

    s.on('message:new', msg => {
      appendMessage(msg);
      scrollToBottom();
    });

    s.on('members:update', members => {
      el.memberCount.textContent = members.length;
      el.memberList.innerHTML = '';
      members.forEach(m => {
        const li = document.createElement('li');
        const av = document.createElement('div');
        av.className = 'avatar sm';
        setAvatar(av, m.username, m.avatar);
        const dot = document.createElement('span');
        dot.className = 'online-dot';
        const name = document.createElement('span');
        name.textContent = m.username + (m.username === state.username ? ' (you)' : '');
        li.append(av, dot, name);
        el.memberList.appendChild(li);
      });
    });

    s.on('typing:update', ({ username, typing }) => {
      if (typing) state.typingUsers.add(username);
      else state.typingUsers.delete(username);
      renderTypingBar();
    });

    s.on('room:created', room => {
      state.rooms.push(room);
      addRoomToSidebar(room);
    });

    s.on('error', ({ message }) => {
      alert('Error: ' + message);
    });
  }

  // ─── Chat Events ─────────────────────────────────────────────────────────────
  function bindChatEvents() {
    // Send on button click
    el.sendBtn.addEventListener('click', sendMessage);

    // Send on Enter (Shift+Enter = newline)
    el.msgInput.addEventListener('keydown', e => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        sendMessage();
      }
    });

    // Auto-resize textarea
    el.msgInput.addEventListener('input', () => {
      el.msgInput.style.height = 'auto';
      el.msgInput.style.height = Math.min(el.msgInput.scrollHeight, 120) + 'px';
      handleTyping();
    });

    // Logout
    el.logoutBtn.addEventListener('click', () => {
      if (confirm('Leave the chat?')) location.reload();
    });

    // Mobile sidebar toggle
    el.sidebarToggle?.addEventListener('click', () => {
      el.sidebar.classList.toggle('open');
    });
  }

  function sendMessage() {
    const text = el.msgInput.value.trim();
    if (!text) return;
    state.socket.emit('message:send', { text });
    el.msgInput.value = '';
    el.msgInput.style.height = 'auto';
    stopTyping();
  }

  // ─── Typing ──────────────────────────────────────────────────────────────────
  function handleTyping() {
    if (!state.isTyping) {
      state.isTyping = true;
      state.socket.emit('typing:start');
    }
    clearTimeout(state.typingTimer);
    state.typingTimer = setTimeout(stopTyping, 2000);
  }

  function stopTyping() {
    if (state.isTyping) {
      state.isTyping = false;
      state.socket.emit('typing:stop');
    }
  }

  function renderTypingBar() {
    const others = [...state.typingUsers].filter(u => u !== state.username);
    if (!others.length) { el.typingBar.textContent = ''; return; }
    const names = others.slice(0, 3).join(', ');
    el.typingBar.textContent = `${names} ${others.length === 1 ? 'is' : 'are'} typing…`;
  }

  // ─── Room Events ─────────────────────────────────────────────────────────────
  function bindRoomEvents() {
    loadSidebarRooms();

    el.newRoomBtn.addEventListener('click', () => {
      el.modalOverlay.classList.remove('hidden');
      el.newRoomInput.focus();
    });

    el.modalCancel.addEventListener('click', closeModal);
    el.modalOverlay.addEventListener('click', e => { if (e.target === el.modalOverlay) closeModal(); });

    el.modalCreate.addEventListener('click', createRoom);
    el.newRoomInput.addEventListener('keydown', e => { if (e.key === 'Enter') createRoom(); });
  }

  function loadSidebarRooms() {
    el.roomList.innerHTML = '';
    state.rooms.forEach(addRoomToSidebar);
    // mark current
    updateActiveRoom(state.currentRoom);
    updateRoomHeader();
  }

  function addRoomToSidebar(room) {
    const li = document.createElement('li');
    li.textContent = room.name;
    li.dataset.id = room.id;
    if (room.id === state.currentRoom) li.classList.add('active');
    li.addEventListener('click', () => switchRoom(room.id));
    el.roomList.appendChild(li);
  }

  function switchRoom(roomId) {
    if (roomId === state.currentRoom) return;
    state.currentRoom = roomId;
    state.socket.emit('room:switch', { roomId });
    updateActiveRoom(roomId);
    updateRoomHeader();
    el.messages.innerHTML = '';
    el.sidebar.classList.remove('open');
  }

  function updateActiveRoom(roomId) {
    document.querySelectorAll('#room-list li').forEach(li => {
      li.classList.toggle('active', li.dataset.id === roomId);
    });
  }

  function updateRoomHeader() {
    const room = state.rooms.find(r => r.id === state.currentRoom);
    if (room) {
      el.roomTitle.textContent = room.name;
      el.roomMeta.textContent = `# ${room.id}`;
    }
  }

  async function createRoom() {
    const name = el.newRoomInput.value.trim();
    if (!name) { el.modalError.textContent = 'Enter a room name.'; return; }
    try {
      const res = await fetch('/api/rooms', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name })
      });
      const data = await res.json();
      if (!res.ok) { el.modalError.textContent = data.error; return; }
      closeModal();
      // Room:created will be emitted by server via socket
    } catch {
      el.modalError.textContent = 'Something went wrong.';
    }
  }

  function closeModal() {
    el.modalOverlay.classList.add('hidden');
    el.newRoomInput.value = '';
    el.modalError.textContent = '';
  }

  // ─── Message Rendering ───────────────────────────────────────────────────────
  function appendMessage(msg) {
    const div = document.createElement('div');

    if (msg.type === 'system') {
      div.className = 'msg system';
      const text = document.createElement('span');
      text.className = 'msg-text';
      text.textContent = msg.text;
      div.appendChild(text);
    } else {
      const isOwn = msg.username === state.username;
      div.className = 'msg' + (isOwn ? ' own' : '');

      const avEl = document.createElement('div');
      avEl.className = 'avatar msg-avatar';
      setAvatar(avEl, msg.username, msg.avatar);

      const body = document.createElement('div');
      body.className = 'msg-body';

      const meta = document.createElement('div');
      meta.className = 'msg-meta';
      const author = document.createElement('span');
      author.className = 'msg-author';
      author.textContent = isOwn ? 'You' : msg.username;
      const time = document.createElement('span');
      time.className = 'msg-time';
      time.textContent = formatTime(msg.timestamp);
      meta.append(author, time);

      const text = document.createElement('div');
      text.className = 'msg-text';
      text.textContent = msg.text;

      body.append(meta, text);
      div.append(avEl, body);
    }

    el.messages.appendChild(div);
  }

  // ─── Helpers ─────────────────────────────────────────────────────────────────
  function setAvatar(el, username, avatarData) {
    const colors = ['#6366f1','#8b5cf6','#ec4899','#14b8a6','#f59e0b','#10b981','#3b82f6','#ef4444'];
    const color = avatarData?.color || colors[username.charCodeAt(0) % colors.length];
    const initials = (avatarData?.initials || username.slice(0, 2)).toUpperCase();
    el.style.background = color;
    el.textContent = initials;
  }

  function renderAvatar(el, username) {
    setAvatar(el, username, null);
  }

  function scrollToBottom() {
    el.messages.scrollTop = el.messages.scrollHeight;
  }

  function setConnected(online) {
    el.connDot.className = 'conn-dot ' + (online ? 'online' : 'offline');
    el.connDot.title = online ? 'Connected' : 'Disconnected';
  }

  function formatTime(ts) {
    const d = new Date(ts);
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }

  // ─── Boot ────────────────────────────────────────────────────────────────────
  init();
})();
