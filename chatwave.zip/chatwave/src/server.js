/**
 * ChatWave – Real-time Chat Server
 * Stack: Node.js · Express · Socket.io
 */

const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: '*' }
});

// ─── Static Files ────────────────────────────────────────────────────────────
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));

// ─── In-Memory State ─────────────────────────────────────────────────────────
const rooms = new Map();   // roomId → { name, createdAt, messages[] }
const users = new Map();   // socketId → { id, username, room, avatar, joinedAt }

// Seed two default rooms
['General', 'Tech Talk'].forEach(name => {
  const id = name.toLowerCase().replace(' ', '-');
  rooms.set(id, { id, name, messages: [], createdAt: new Date() });
});

// ─── REST API ─────────────────────────────────────────────────────────────────
app.get('/api/rooms', (req, res) => {
  const list = Array.from(rooms.values()).map(r => ({
    id: r.id,
    name: r.name,
    createdAt: r.createdAt,
    memberCount: [...users.values()].filter(u => u.room === r.id).length,
    messageCount: r.messages.length
  }));
  res.json(list);
});

app.post('/api/rooms', (req, res) => {
  const { name } = req.body;
  if (!name || !name.trim()) return res.status(400).json({ error: 'Room name required' });
  const id = name.trim().toLowerCase().replace(/\s+/g, '-') + '-' + uuidv4().slice(0, 6);
  if ([...rooms.values()].some(r => r.name.toLowerCase() === name.trim().toLowerCase())) {
    return res.status(409).json({ error: 'A room with that name already exists' });
  }
  const room = { id, name: name.trim(), messages: [], createdAt: new Date() };
  rooms.set(id, room);
  io.emit('room:created', { id: room.id, name: room.name, createdAt: room.createdAt, memberCount: 0, messageCount: 0 });
  res.status(201).json(room);
});

app.get('/api/rooms/:id/messages', (req, res) => {
  const room = rooms.get(req.params.id);
  if (!room) return res.status(404).json({ error: 'Room not found' });
  res.json(room.messages.slice(-100)); // last 100 messages
});

// ─── Socket.io Events ─────────────────────────────────────────────────────────
io.on('connection', (socket) => {
  console.log(`[+] Socket connected: ${socket.id}`);

  // Join a room
  socket.on('user:join', ({ username, roomId }) => {
    if (!username || !roomId || !rooms.has(roomId)) {
      return socket.emit('error', { message: 'Invalid username or room.' });
    }

    const user = {
      id: socket.id,
      username: username.trim(),
      room: roomId,
      avatar: generateAvatar(username),
      joinedAt: new Date()
    };
    users.set(socket.id, user);
    socket.join(roomId);

    // Send message history
    socket.emit('messages:history', rooms.get(roomId).messages.slice(-100));

    // Notify room of new member
    const systemMsg = buildMessage({ username: 'System', text: `${user.username} joined the room`, type: 'system' });
    rooms.get(roomId).messages.push(systemMsg);
    io.to(roomId).emit('message:new', systemMsg);

    // Broadcast updated member list
    broadcastMembers(roomId);

    console.log(`[>] ${user.username} joined room: ${roomId}`);
  });

  // New chat message
  socket.on('message:send', ({ text }) => {
    const user = users.get(socket.id);
    if (!user || !text || !text.trim()) return;

    const msg = buildMessage({ username: user.username, text: text.trim(), avatar: user.avatar, type: 'user' });
    rooms.get(user.room).messages.push(msg);
    io.to(user.room).emit('message:new', msg);
  });

  // Typing indicator
  socket.on('typing:start', () => {
    const user = users.get(socket.id);
    if (user) socket.to(user.room).emit('typing:update', { username: user.username, typing: true });
  });

  socket.on('typing:stop', () => {
    const user = users.get(socket.id);
    if (user) socket.to(user.room).emit('typing:update', { username: user.username, typing: false });
  });

  // Switch rooms
  socket.on('room:switch', ({ roomId }) => {
    const user = users.get(socket.id);
    if (!user || !rooms.has(roomId)) return;

    const oldRoom = user.room;
    socket.leave(oldRoom);

    const leaveMsg = buildMessage({ username: 'System', text: `${user.username} left the room`, type: 'system' });
    rooms.get(oldRoom).messages.push(leaveMsg);
    io.to(oldRoom).emit('message:new', leaveMsg);
    broadcastMembers(oldRoom);

    user.room = roomId;
    socket.join(roomId);

    socket.emit('messages:history', rooms.get(roomId).messages.slice(-100));

    const joinMsg = buildMessage({ username: 'System', text: `${user.username} joined the room`, type: 'system' });
    rooms.get(roomId).messages.push(joinMsg);
    io.to(roomId).emit('message:new', joinMsg);
    broadcastMembers(roomId);
  });

  // Disconnect
  socket.on('disconnect', () => {
    const user = users.get(socket.id);
    if (user) {
      const msg = buildMessage({ username: 'System', text: `${user.username} left the chat`, type: 'system' });
      rooms.get(user.room)?.messages.push(msg);
      io.to(user.room).emit('message:new', msg);
      users.delete(socket.id);
      broadcastMembers(user.room);
      console.log(`[-] ${user.username} disconnected`);
    }
  });
});

// ─── Helpers ──────────────────────────────────────────────────────────────────
function buildMessage({ username, text, avatar = null, type = 'user' }) {
  return { id: uuidv4(), username, text, avatar, type, timestamp: new Date() };
}

function broadcastMembers(roomId) {
  const members = [...users.values()]
    .filter(u => u.room === roomId)
    .map(u => ({ id: u.id, username: u.username, avatar: u.avatar }));
  io.to(roomId).emit('members:update', members);
}

function generateAvatar(username) {
  const colors = ['#6366f1','#8b5cf6','#ec4899','#14b8a6','#f59e0b','#10b981','#3b82f6','#ef4444'];
  const color = colors[username.charCodeAt(0) % colors.length];
  return { initials: username.slice(0, 2).toUpperCase(), color };
}

// ─── Start ────────────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`\n🚀 ChatWave running at http://localhost:${PORT}\n`);
});
