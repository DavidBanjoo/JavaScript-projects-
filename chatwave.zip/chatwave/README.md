# ChatWave 🌊

A real-time group chat application built with **Node.js**, **Express**, and **Socket.io**.

## Features

- **Real-time messaging** — messages delivered instantly via WebSockets
- **Multiple chat rooms** — join existing rooms or create your own
- **Live member list** — see who's online in each room
- **Typing indicators** — know when someone is composing a message
- **Message history** — last 100 messages loaded when you join a room
- **REST API** — room listing and creation via HTTP endpoints
- **Mobile responsive** — works on phones and tablets

## Tech Stack

| Layer    | Technology              |
|----------|-------------------------|
| Runtime  | Node.js                 |
| Server   | Express 4               |
| Realtime | Socket.io 4             |
| Frontend | Vanilla JS (ES6 IIFE)   |
| Styling  | Custom CSS (no framework) |

## Project Structure

```
chatwave/
├── src/
│   └── server.js        # Express + Socket.io server
├── public/
│   ├── index.html       # Single-page frontend
│   ├── css/
│   │   └── style.css    # All styles
│   └── js/
│       └── app.js       # Frontend Socket.io client
├── package.json
└── README.md
```

## Getting Started

### Prerequisites
- Node.js v16+ installed

### Install & Run

```bash
# 1. Install dependencies
npm install

# 2. Start the server
npm start

# For development with auto-reload:
npm run dev
```

Then open **http://localhost:3000** in your browser.

## API Endpoints

| Method | Route                    | Description           |
|--------|--------------------------|-----------------------|
| GET    | `/api/rooms`             | List all rooms        |
| POST   | `/api/rooms`             | Create a new room     |
| GET    | `/api/rooms/:id/messages`| Get room message history |

### POST /api/rooms

```json
{ "name": "My New Room" }
```

## Socket.io Events

### Client → Server

| Event          | Payload                        | Description           |
|----------------|--------------------------------|-----------------------|
| `user:join`    | `{ username, roomId }`         | Join a room           |
| `message:send` | `{ text }`                     | Send a message        |
| `room:switch`  | `{ roomId }`                   | Switch to another room|
| `typing:start` | —                              | User started typing   |
| `typing:stop`  | —                              | User stopped typing   |

### Server → Client

| Event            | Payload                        | Description           |
|------------------|--------------------------------|-----------------------|
| `messages:history` | `Message[]`                  | Chat history on join  |
| `message:new`    | `Message`                      | New incoming message  |
| `members:update` | `Member[]`                     | Updated member list   |
| `typing:update`  | `{ username, typing }`         | Typing state change   |
| `room:created`   | `Room`                         | A new room was created|

## Design Decisions

- **In-memory storage** — chosen for simplicity. In production, swap for Redis (pub/sub across instances) + PostgreSQL (persistence).
- **IIFE pattern** — frontend JS uses a self-invoking function for encapsulation, avoiding global scope pollution without a build step.
- **REST + WebSocket hybrid** — room creation uses HTTP for reliability; real-time delivery of the new room event is broadcast via Socket.io.
- **No framework on frontend** — demonstrates strong Vanilla JS skills; easy to migrate to React if needed.

## Possible Extensions

- JWT authentication & user accounts
- Persistent storage with MongoDB or PostgreSQL
- Private / direct messages
- File & image sharing
- Read receipts
- Redis adapter for horizontal scaling

---

Built as a full-stack JavaScript portfolio project. 🚀
