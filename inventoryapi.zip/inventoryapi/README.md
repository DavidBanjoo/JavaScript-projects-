# InventoryAPI ⬡

A production-style **Inventory Management REST API** built with **Spring Boot 3**, **Spring Data JPA**, and an H2 in-memory database. Includes a live HTML/JS dashboard served by Spring.

## Tech Stack

| Layer          | Technology                        |
|----------------|-----------------------------------|
| Language       | Java 17                           |
| Framework      | Spring Boot 3.2                   |
| Web layer      | Spring MVC (REST)                 |
| Persistence    | Spring Data JPA + Hibernate       |
| Database       | H2 (in-memory, zero-config)       |
| Validation     | Jakarta Bean Validation           |
| Build tool     | Maven                             |
| Testing        | JUnit 5 + MockMvc                 |
| Frontend       | Vanilla JS + Chart.js (dashboard) |

## Project Structure

```
inventoryapi/
├── src/main/java/com/flamytech/inventory/
│   ├── InventoryApiApplication.java   # Entry point
│   ├── controller/
│   │   ├── ProductController.java     # REST endpoints for products
│   │   └── CategoryController.java   # REST endpoints for categories
│   ├── service/
│   │   ├── ProductService.java        # Business logic
│   │   └── CategoryService.java
│   ├── repository/
│   │   ├── ProductRepository.java     # JPA queries (JPQL + custom)
│   │   └── CategoryRepository.java
│   ├── model/
│   │   ├── Product.java               # JPA entity with validation
│   │   └── Category.java
│   └── exception/
│       ├── GlobalExceptionHandler.java  # RFC 7807 Problem Details
│       ├── ResourceNotFoundException.java
│       ├── DuplicateResourceException.java
│       └── BadRequestException.java
├── src/main/resources/
│   ├── application.properties
│   ├── data.sql                        # Seed data
│   └── static/                         # Dashboard (served by Spring)
│       ├── index.html
│       ├── css/dashboard.css
│       └── js/dashboard.js
├── src/test/
│   └── ProductControllerTest.java      # Integration tests (MockMvc)
└── pom.xml
```

## Prerequisites

- **Java 17+** (check: `java -version`)
- **Maven 3.8+** (check: `mvn -version`)

## Getting Started

```bash
# 1. Build the project
mvn clean package -DskipTests

# 2. Run
mvn spring-boot:run

# OR run the jar directly
java -jar target/inventory-api-1.0.0.jar
```

Open **http://localhost:8080** → live dashboard

H2 Console: **http://localhost:8080/h2-console**
- JDBC URL: `jdbc:h2:mem:inventorydb`
- Username: `sa` / Password: *(empty)*

## Run Tests

```bash
mvn test
```

## API Reference

### Products `/api/v1/products`

| Method | Endpoint                     | Description                        |
|--------|------------------------------|------------------------------------|
| GET    | `/api/v1/products`           | List all (paginated, sortable)     |
| GET    | `/api/v1/products/{id}`      | Get by ID                          |
| GET    | `/api/v1/products/sku/{sku}` | Get by SKU                         |
| GET    | `/api/v1/products/search?q=` | Full-text search                   |
| GET    | `/api/v1/products/low-stock` | Products below stock threshold     |
| GET    | `/api/v1/products/stats`     | Aggregate stats + inventory value  |
| GET    | `/api/v1/products/category/{id}` | Products in a category         |
| POST   | `/api/v1/products`           | Create a product                   |
| PUT    | `/api/v1/products/{id}`      | Full update                        |
| PATCH  | `/api/v1/products/{id}/stock?delta=N` | Adjust stock (+/-)        |
| DELETE | `/api/v1/products/{id}`      | Delete a product                   |

### Categories `/api/v1/categories`

| Method | Endpoint                  | Description       |
|--------|---------------------------|-------------------|
| GET    | `/api/v1/categories`      | List all          |
| GET    | `/api/v1/categories/{id}` | Get by ID         |
| POST   | `/api/v1/categories`      | Create            |
| PUT    | `/api/v1/categories/{id}` | Update            |
| DELETE | `/api/v1/categories/{id}` | Delete (guarded)  |

### Query Parameters

`GET /api/v1/products?page=0&size=10&sort=name&dir=asc`

### Sample Request – Create Product

```json
POST /api/v1/products
{
  "name": "Wireless Mouse",
  "sku": "ELEC-005",
  "price": 8500,
  "quantity": 40,
  "lowStockThreshold": 10,
  "description": "Ergonomic, 2.4GHz, 1 year battery life",
  "category": { "id": 1 }
}
```

### Error Response (RFC 7807 Problem Details)

```json
{
  "type": "https://flamytech.dev/errors/validation",
  "title": "Validation Failed",
  "status": 400,
  "detail": "One or more fields failed validation.",
  "timestamp": "2026-06-19T10:00:00Z",
  "fieldErrors": {
    "name": "Product name is required",
    "sku": "SKU must be 3-20 uppercase letters, digits, or hyphens"
  }
}
```

## Design Decisions

- **Layered architecture** — Controller → Service → Repository, each with a single responsibility
- **RFC 7807 Problem Details** — industry-standard error format (`GlobalExceptionHandler`)
- **Transactional boundaries** — `@Transactional(readOnly = true)` on service, overridden for writes
- **Cascade delete guard** — deleting a category with products is blocked with a 400, not silently cascaded
- **JPQL custom queries** — full-text search, low-stock filter, aggregate stats, stock delta update
- **H2 in-memory** — zero-config for portfolio demo; swap datasource for PostgreSQL in production

## Production Extensions

- PostgreSQL / MySQL datasource
- Spring Security + JWT authentication
- Flyway for database migrations
- Swagger / OpenAPI documentation (`springdoc-openapi`)
- Docker + docker-compose
- Redis caching for stats endpoint

---

Built as a Java Spring Boot portfolio project by Victor · FlamyTech 🚀
