package com.flamytech.inventory;

import com.flamytech.inventory.model.Product;
import com.flamytech.inventory.repository.ProductRepository;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;

import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@Transactional   // rolls back after each test
@DisplayName("Product API Integration Tests")
class ProductControllerTest {

    @Autowired MockMvc mvc;
    @Autowired ProductRepository productRepo;

    // ── GET all products ────────────────────────────────────────────────────
    @Test
    @DisplayName("GET /api/v1/products → 200 with paginated list")
    void getAllProducts() throws Exception {
        mvc.perform(get("/api/v1/products"))
           .andExpect(status().isOk())
           .andExpect(jsonPath("$.content", not(empty())))
           .andExpect(jsonPath("$.totalElements", greaterThan(0)));
    }

    // ── GET by id ───────────────────────────────────────────────────────────
    @Test
    @DisplayName("GET /api/v1/products/1 → 200 with correct product")
    void getProductById() throws Exception {
        mvc.perform(get("/api/v1/products/1"))
           .andExpect(status().isOk())
           .andExpect(jsonPath("$.id", is(1)));
    }

    @Test
    @DisplayName("GET /api/v1/products/9999 → 404")
    void getProductNotFound() throws Exception {
        mvc.perform(get("/api/v1/products/9999"))
           .andExpect(status().isNotFound())
           .andExpect(jsonPath("$.title", is("Resource Not Found")));
    }

    // ── Search ──────────────────────────────────────────────────────────────
    @Test
    @DisplayName("GET /api/v1/products/search?q=keyboard → matches found")
    void searchProducts() throws Exception {
        mvc.perform(get("/api/v1/products/search?q=keyboard"))
           .andExpect(status().isOk())
           .andExpect(jsonPath("$.content", not(empty())));
    }

    // ── Low stock ───────────────────────────────────────────────────────────
    @Test
    @DisplayName("GET /api/v1/products/low-stock → 200 list")
    void getLowStock() throws Exception {
        mvc.perform(get("/api/v1/products/low-stock"))
           .andExpect(status().isOk())
           .andExpect(jsonPath("$", isA(java.util.List.class)));
    }

    // ── Stats ───────────────────────────────────────────────────────────────
    @Test
    @DisplayName("GET /api/v1/products/stats → has expected keys")
    void getStats() throws Exception {
        mvc.perform(get("/api/v1/products/stats"))
           .andExpect(status().isOk())
           .andExpect(jsonPath("$.totalProducts",       notNullValue()))
           .andExpect(jsonPath("$.totalInventoryValue", notNullValue()))
           .andExpect(jsonPath("$.lowStockCount",       notNullValue()));
    }

    // ── POST create ─────────────────────────────────────────────────────────
    @Test
    @DisplayName("POST /api/v1/products → 201 with Location header")
    void createProduct() throws Exception {
        String body = """
            {
              "name": "Test Monitor 27\\"",
              "sku": "TEST-MON-27",
              "price": 45000,
              "quantity": 5,
              "description": "4K IPS panel"
            }
            """;
        mvc.perform(post("/api/v1/products")
              .contentType(MediaType.APPLICATION_JSON)
              .content(body))
           .andExpect(status().isCreated())
           .andExpect(header().exists("Location"))
           .andExpect(jsonPath("$.sku", is("TEST-MON-27")));
    }

    @Test
    @DisplayName("POST /api/v1/products with blank name → 400 validation error")
    void createProductValidationFail() throws Exception {
        String body = """
            { "name": "", "sku": "BAD-001", "price": 100, "quantity": 1 }
            """;
        mvc.perform(post("/api/v1/products")
              .contentType(MediaType.APPLICATION_JSON)
              .content(body))
           .andExpect(status().isBadRequest())
           .andExpect(jsonPath("$.fieldErrors.name", notNullValue()));
    }

    // ── PATCH stock ─────────────────────────────────────────────────────────
    @Test
    @DisplayName("PATCH /api/v1/products/1/stock?delta=10 → quantity increased")
    void adjustStock() throws Exception {
        int before = productRepo.findById(1L).orElseThrow().getQuantity();
        mvc.perform(patch("/api/v1/products/1/stock?delta=10"))
           .andExpect(status().isOk())
           .andExpect(jsonPath("$.quantity", is(before + 10)));
    }

    @Test
    @DisplayName("PATCH stock with delta that makes quantity negative → 400")
    void adjustStockNegative() throws Exception {
        mvc.perform(patch("/api/v1/products/1/stock?delta=-99999"))
           .andExpect(status().isBadRequest());
    }

    // ── DELETE ──────────────────────────────────────────────────────────────
    @Test
    @DisplayName("DELETE /api/v1/products/1 → 204 No Content")
    void deleteProduct() throws Exception {
        mvc.perform(delete("/api/v1/products/1"))
           .andExpect(status().isNoContent());
    }
}
