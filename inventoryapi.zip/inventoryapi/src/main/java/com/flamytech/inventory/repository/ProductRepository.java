package com.flamytech.inventory.repository;

import com.flamytech.inventory.model.Product;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {

    Optional<Product> findBySku(String sku);

    boolean existsBySku(String sku);

    List<Product> findByCategoryId(Long categoryId);

    Page<Product> findByCategoryId(Long categoryId, Pageable pageable);

    /** Full-text search across name, description, and SKU */
    @Query("""
        SELECT p FROM Product p
        WHERE LOWER(p.name)        LIKE LOWER(CONCAT('%', :q, '%'))
           OR LOWER(p.description) LIKE LOWER(CONCAT('%', :q, '%'))
           OR LOWER(p.sku)         LIKE LOWER(CONCAT('%', :q, '%'))
        """)
    Page<Product> search(@Param("q") String query, Pageable pageable);

    /** Products where quantity <= lowStockThreshold */
    @Query("SELECT p FROM Product p WHERE p.quantity <= p.lowStockThreshold")
    List<Product> findLowStock();

    /** Adjust stock quantity by a signed delta (+/-) */
    @Modifying
    @Query("UPDATE Product p SET p.quantity = p.quantity + :delta WHERE p.id = :id")
    int adjustStock(@Param("id") Long id, @Param("delta") int delta);

    /** Total number of products per category */
    @Query("""
        SELECT p.category.name, COUNT(p)
        FROM Product p
        WHERE p.category IS NOT NULL
        GROUP BY p.category.name
        """)
    List<Object[]> countByCategory();

    /** Inventory value = SUM(price * quantity) */
    @Query("SELECT COALESCE(SUM(p.price * p.quantity), 0) FROM Product p")
    java.math.BigDecimal totalInventoryValue();
}
