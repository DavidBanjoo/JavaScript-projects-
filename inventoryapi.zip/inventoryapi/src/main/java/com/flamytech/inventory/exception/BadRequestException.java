package com.flamytech.inventory.exception;

public class BadRequestException extends RuntimeException {
    public BadRequestException(String message) { super(message); }
}
