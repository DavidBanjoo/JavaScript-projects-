package com.flamytech.inventory.service;

import com.flamytech.inventory.exception.*;
import com.flamytech.inventory.model.*;
import com.flamytech.inventory.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.*;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class ProductService {

    private final ProductRepository productRepo;
    private final CategoryRepository categoryRepo;

    // ── Read ──────────────────────────────────────────────────────────────────

    public Page<Product> getAll(int page, int size, String sort, String dir) {
        Sort.Direction direction = dir.equalsIgnoreCase("desc") ? Sort.Direction.DESC : Sort.Direction.ASC;
        Pageable pageable = PageRequest.of(page, size, Sort.by(direction, sort));
        return productRepo.findAll(pageable);
    }

    public Product getById(Long id) {
        return productRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Product", id));
    }

    public Product getBySku(String sku) {
        return productRepo.findBySku(sku)
                .orElseThrow(() -> new ResourceNotFoundException("Product with SKU '" + sku + "' not found"));
    }

    public Page<Product> search(String query, int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("name"));
        return productRepo.search(query, pageable);
    }

    public List<Product> getLowStock() {
        return productRepo.findLowStock();
    }

    public List<Product> getByCategory(Long categoryId) {
        categoryRepo.findById(categoryId)
                .orElseThrow(() -> new ResourceNotFoundException("Category", categoryId));
        return productRepo.findByCategoryId(categoryId);
    }

    // ── Write ─────────────────────────────────────────────────────────────────

    @Transactional
    public Product create(Product product) {
        if (productRepo.existsBySku(product.getSku())) {
            throw new DuplicateResourceException("A product with SKU '" + product.getSku() + "' already exists");
        }
        resolveCategory(product);
        return productRepo.save(product);
    }

    @Transactional
    public Product update(Long id, Product incoming) {
        Product existing = getById(id);

        // SKU uniqueness: allow same SKU on same product, reject if taken by another
        if (!existing.getSku().equalsIgnoreCase(incoming.getSku())
                && productRepo.existsBySku(incoming.getSku())) {
            throw new DuplicateResourceException("SKU '" + incoming.getSku() + "' is already used by another product");
        }

        existing.setName(incoming.getName());
        existing.setDescription(incoming.getDescription());
        existing.setSku(incoming.getSku().toUpperCase());
        existing.setPrice(incoming.getPrice());
        existing.setQuantity(incoming.getQuantity());
        existing.setLowStockThreshold(incoming.getLowStockThreshold());
        existing.setCategory(incoming.getCategory());
        resolveCategory(existing);

        return productRepo.save(existing);
    }

    @Transactional
    public Product adjustStock(Long id, int delta) {
        Product product = getById(id);
        int newQty = product.getQuantity() + delta;
        if (newQty < 0) {
            throw new BadRequestException(
                "Insufficient stock. Available: " + product.getQuantity() + ", requested delta: " + delta);
        }
        productRepo.adjustStock(id, delta);
        product.setQuantity(newQty);
        return product;
    }

    @Transactional
    public void delete(Long id) {
        if (!productRepo.existsById(id)) {
            throw new ResourceNotFoundException("Product", id);
        }
        productRepo.deleteById(id);
    }

    // ── Stats ─────────────────────────────────────────────────────────────────

    public Map<String, Object> getStats() {
        List<Product> all = productRepo.findAll();
        List<Product> lowStock = productRepo.findLowStock();
        BigDecimal totalValue = productRepo.totalInventoryValue();
        List<Object[]> byCategory = productRepo.countByCategory();

        Map<String, Long> categoryBreakdown = new LinkedHashMap<>();
        byCategory.forEach(row -> categoryBreakdown.put((String) row[0], (Long) row[1]));

        Map<String, Object> stats = new LinkedHashMap<>();
        stats.put("totalProducts", all.size());
        stats.put("totalCategories", categoryRepo.count());
        stats.put("lowStockCount", lowStock.size());
        stats.put("outOfStockCount", all.stream().filter(p -> p.getQuantity() == 0).count());
        stats.put("totalInventoryValue", totalValue);
        stats.put("productsByCategory", categoryBreakdown);
        return stats;
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private void resolveCategory(Product product) {
        if (product.getCategory() != null && product.getCategory().getId() != null) {
            Category category = categoryRepo.findById(product.getCategory().getId())
                    .orElseThrow(() -> new ResourceNotFoundException("Category", product.getCategory().getId()));
            product.setCategory(category);
        }
    }
}
