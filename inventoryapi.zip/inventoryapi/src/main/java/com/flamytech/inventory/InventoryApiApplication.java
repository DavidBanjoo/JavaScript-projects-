package com.flamytech.inventory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * InventoryAPI – Spring Boot Portfolio Project
 *
 * A production-style Inventory Management REST API demonstrating:
 *  - Layered architecture  (Controller → Service → Repository)
 *  - Spring Data JPA       (entity mapping, CRUD, custom queries)
 *  - Bean Validation       (@Valid, constraint annotations)
 *  - Global exception handling (RFC 7807 Problem Details)
 *  - H2 in-memory database (zero-config, H2 Console at /h2-console)
 *  - Static dashboard      (Vanilla JS + Chart.js, served by Spring)
 */
@SpringBootApplication
public class InventoryApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(InventoryApiApplication.class, args);
    }
}
