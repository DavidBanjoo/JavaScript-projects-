package com.flamytech.inventory.service;

import com.flamytech.inventory.exception.*;
import com.flamytech.inventory.model.Category;
import com.flamytech.inventory.repository.CategoryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional(readOnly = true)
public class CategoryService {

    private final CategoryRepository categoryRepo;

    public List<Category> getAll() {
        return categoryRepo.findAll();
    }

    public Category getById(Long id) {
        return categoryRepo.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Category", id));
    }

    @Transactional
    public Category create(Category category) {
        if (categoryRepo.existsByNameIgnoreCase(category.getName())) {
            throw new DuplicateResourceException(
                "Category '" + category.getName() + "' already exists");
        }
        return categoryRepo.save(category);
    }

    @Transactional
    public Category update(Long id, Category incoming) {
        Category existing = getById(id);
        if (!existing.getName().equalsIgnoreCase(incoming.getName())
                && categoryRepo.existsByNameIgnoreCase(incoming.getName())) {
            throw new DuplicateResourceException(
                "Category '" + incoming.getName() + "' already exists");
        }
        existing.setName(incoming.getName());
        existing.setDescription(incoming.getDescription());
        return categoryRepo.save(existing);
    }

    @Transactional
    public void delete(Long id) {
        Category cat = getById(id);
        if (!cat.getProducts().isEmpty()) {
            throw new BadRequestException(
                "Cannot delete category '" + cat.getName() + "': it still has " +
                cat.getProducts().size() + " product(s). Reassign or delete them first.");
        }
        categoryRepo.deleteById(id);
    }
}
