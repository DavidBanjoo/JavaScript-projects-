/**
 * InventoryAPI Dashboard
 * Vanilla JS SPA that consumes the Spring Boot REST API
 */
(() => {
  'use strict';

  const BASE = '/api/v1';

  // ── API client ──────────────────────────────────────────────────────────────
  const api = {
    async req(method, path, body) {
      const res = await fetch(BASE + path, {
        method,
        headers: { 'Content-Type': 'application/json' },
        ...(body ? { body: JSON.stringify(body) } : {})
      });
      if (res.status === 204) return null;
      const data = await res.json();
      if (!res.ok) throw new Error(data.detail || data.title || 'Request failed');
      return data;
    },
    get:    p       => api.req('GET',    p),
    post:   (p, b)  => api.req('POST',   p, b),
    put:    (p, b)  => api.req('PUT',    p, b),
    patch:  (p, b)  => api.req('PATCH',  p, b),
    delete: p       => api.req('DELETE', p),
  };

  // ── DOM ─────────────────────────────────────────────────────────────────────
  const $ = id => document.getElementById(id);
  const main          = $('main');
  const topbarTitle   = $('topbar-title');
  const topbarActions = $('topbar-actions');
  const modalOverlay  = $('modal-overlay');
  const modalTitle    = $('modal-title');
  const modalBody     = $('modal-body');

  $('modal-close').addEventListener('click', closeModal);
  modalOverlay.addEventListener('click', e => { if (e.target === modalOverlay) closeModal(); });
  document.querySelectorAll('.nav-btn').forEach(btn => {
    btn.addEventListener('click', () => navigate(btn.dataset.view));
  });

  // ── Router ──────────────────────────────────────────────────────────────────
  function navigate(view) {
    document.querySelectorAll('.nav-btn').forEach(b => b.classList.toggle('active', b.dataset.view === view));
    ({ dashboard, products, categories, lowstock })[view]?.();
  }

  // ── Dashboard ───────────────────────────────────────────────────────────────
  async function dashboard() {
    topbarTitle.textContent = 'Dashboard';
    topbarActions.innerHTML = '';
    main.innerHTML = '<p style="color:var(--dim)">Loading…</p>';

    const [stats, cats] = await Promise.all([
      api.get('/products/stats'),
      api.get('/categories'),
    ]);

    const val = new Intl.NumberFormat('en-NG', { style: 'currency', currency: 'NGN', maximumFractionDigits: 0 })
                        .format(stats.totalInventoryValue);

    main.innerHTML = `
      <div class="stats-grid">
        <div class="stat-card"><div class="stat-label">Products</div><div class="stat-value accent">${stats.totalProducts}</div></div>
        <div class="stat-card"><div class="stat-label">Categories</div><div class="stat-value">${stats.totalCategories}</div></div>
        <div class="stat-card"><div class="stat-label">Low Stock</div><div class="stat-value warn">${stats.lowStockCount}</div></div>
        <div class="stat-card"><div class="stat-label">Out of Stock</div><div class="stat-value danger">${stats.outOfStockCount}</div></div>
        <div class="stat-card" style="grid-column:span 2"><div class="stat-label">Inventory Value</div><div class="stat-value green" style="font-size:22px">${val}</div></div>
      </div>
      <div class="charts-row">
        <div class="chart-card"><h3>Products by Category</h3><canvas id="cat-chart"></canvas></div>
        <div class="chart-card"><h3>Stock Status</h3><canvas id="stock-chart"></canvas></div>
      </div>
    `;

    // Pie – products per category
    const catLabels = Object.keys(stats.productsByCategory);
    const catData   = Object.values(stats.productsByCategory);
    new Chart($('cat-chart'), {
      type: 'doughnut',
      data: {
        labels: catLabels,
        datasets: [{ data: catData, backgroundColor: ['#6d6afa','#10b981','#f59e0b','#ef4444','#8b5cf6','#3b82f6'], borderWidth: 0 }]
      },
      options: { plugins: { legend: { labels: { color: '#7a84a0', font: { size: 12 } } } }, cutout: '65%' }
    });

    // Bar – stock status
    new Chart($('stock-chart'), {
      type: 'bar',
      data: {
        labels: ['In Stock', 'Low Stock', 'Out of Stock'],
        datasets: [{
          data: [
            stats.totalProducts - stats.lowStockCount - stats.outOfStockCount,
            stats.lowStockCount, stats.outOfStockCount
          ],
          backgroundColor: ['#10b981', '#f59e0b', '#f25c5c'],
          borderRadius: 6, borderWidth: 0,
        }]
      },
      options: {
        plugins: { legend: { display: false } },
        scales: {
          x: { ticks: { color: '#7a84a0' }, grid: { color: '#1f2333' } },
          y: { ticks: { color: '#7a84a0', stepSize: 1 }, grid: { color: '#1f2333' } }
        }
      }
    });
  }

  // ── Products ────────────────────────────────────────────────────────────────
  async function products(searchQ = '') {
    topbarTitle.textContent = 'Products';
    topbarActions.innerHTML = `<button class="btn-primary" id="btn-add-prod">+ Add Product</button>`;
    $('btn-add-prod').addEventListener('click', () => openProductModal(null));

    const [data, cats] = await Promise.all([
      searchQ ? api.get(`/products/search?q=${encodeURIComponent(searchQ)}&size=50`)
              : api.get('/products?size=50&sort=name'),
      api.get('/categories'),
    ]);

    const list = data.content ?? data;

    main.innerHTML = `
      <div class="search-bar">
        <input id="search-input" placeholder="Search by name, SKU, description…" value="${esc(searchQ)}"/>
        <button class="btn-secondary" id="search-btn">Search</button>
        ${searchQ ? `<button class="btn-secondary" id="clear-btn">Clear</button>` : ''}
      </div>
      <div class="section-head"><h2>${list.length} product${list.length !== 1 ? 's' : ''}</h2></div>
      <div class="tbl-wrap">
        <table>
          <thead><tr><th>Name</th><th>SKU</th><th>Category</th><th>Price (₦)</th><th>Qty</th><th>Stock</th><th></th></tr></thead>
          <tbody id="prod-tbody"></tbody>
        </table>
      </div>
    `;

    $('search-btn').addEventListener('click', () => products($('search-input').value.trim()));
    $('search-input').addEventListener('keydown', e => { if (e.key === 'Enter') products($('search-input').value.trim()); });
    $('clear-btn')?.addEventListener('click', () => products());

    const tbody = $('prod-tbody');
    if (!list.length) { tbody.innerHTML = `<tr><td colspan="7" style="text-align:center;color:var(--dim);padding:40px">No products found.</td></tr>`; return; }

    list.forEach(p => {
      const stockClass = p.quantity === 0 ? 'out' : p.lowStock ? 'warn' : 'ok';
      const stockLabel = p.quantity === 0 ? 'Out' : p.lowStock ? 'Low' : 'OK';
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td><strong>${esc(p.name)}</strong></td>
        <td><span class="sku">${esc(p.sku)}</span></td>
        <td>${esc(p.category?.name ?? '—')}</td>
        <td>${Number(p.price).toLocaleString('en-NG')}</td>
        <td>${p.quantity}</td>
        <td><span class="badge ${stockClass}">${stockLabel}</span></td>
        <td style="display:flex;gap:6px">
          <button class="btn-icon edit-btn" title="Edit">✎</button>
          <button class="btn-icon del-btn"  title="Delete" style="color:var(--danger)">✕</button>
        </td>
      `;
      tr.querySelector('.edit-btn').addEventListener('click', () => openProductModal(p, cats));
      tr.querySelector('.del-btn').addEventListener('click',  () => confirmDelete('Product', p.name, `/products/${p.id}`, products));
      tbody.appendChild(tr);
    });
  }

  // ── Categories ──────────────────────────────────────────────────────────────
  async function categories() {
    topbarTitle.textContent = 'Categories';
    topbarActions.innerHTML = `<button class="btn-primary" id="btn-add-cat">+ Add Category</button>`;
    $('btn-add-cat').addEventListener('click', () => openCategoryModal(null));

    const list = await api.get('/categories');
    main.innerHTML = `
      <div class="tbl-wrap">
        <table>
          <thead><tr><th>Name</th><th>Description</th><th>Products</th><th></th></tr></thead>
          <tbody id="cat-tbody"></tbody>
        </table>
      </div>
    `;

    const tbody = $('cat-tbody');
    if (!list.length) { tbody.innerHTML = `<tr><td colspan="4" style="text-align:center;color:var(--dim);padding:40px">No categories yet.</td></tr>`; return; }
    list.forEach(c => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td><strong>${esc(c.name)}</strong></td>
        <td style="color:var(--dim)">${esc(c.description ?? '—')}</td>
        <td>${c.productCount}</td>
        <td style="display:flex;gap:6px">
          <button class="btn-icon edit-btn" title="Edit">✎</button>
          <button class="btn-icon del-btn" title="Delete" style="color:var(--danger)">✕</button>
        </td>
      `;
      tr.querySelector('.edit-btn').addEventListener('click', () => openCategoryModal(c));
      tr.querySelector('.del-btn').addEventListener('click',  () => confirmDelete('Category', c.name, `/categories/${c.id}`, categories));
      tbody.appendChild(tr);
    });
  }

  // ── Low Stock ────────────────────────────────────────────────────────────────
  async function lowstock() {
    topbarTitle.textContent = 'Low Stock Alerts';
    topbarActions.innerHTML = '';
    const list = await api.get('/products/low-stock');

    main.innerHTML = `
      <div class="section-head"><h2>${list.length} item${list.length !== 1 ? 's' : ''} need attention</h2></div>
      <div class="tbl-wrap">
        <table>
          <thead><tr><th>Product</th><th>SKU</th><th>Qty</th><th>Threshold</th><th>Status</th><th>Restock</th></tr></thead>
          <tbody id="ls-tbody"></tbody>
        </table>
      </div>
    `;

    const tbody = $('ls-tbody');
    if (!list.length) { tbody.innerHTML = `<tr><td colspan="6" style="text-align:center;color:var(--dim);padding:40px">✅ All products are well stocked!</td></tr>`; return; }

    list.forEach(p => {
      const tr = document.createElement('tr');
      tr.innerHTML = `
        <td><strong>${esc(p.name)}</strong></td>
        <td><span class="sku">${esc(p.sku)}</span></td>
        <td>${p.quantity}</td>
        <td>${p.lowStockThreshold}</td>
        <td><span class="badge ${p.quantity === 0 ? 'out' : 'warn'}">${p.quantity === 0 ? 'Out of Stock' : 'Low Stock'}</span></td>
        <td><button class="btn-secondary restock-btn" data-id="${p.id}">+ Restock</button></td>
      `;
      tbody.appendChild(tr);
    });

    tbody.querySelectorAll('.restock-btn').forEach(btn => {
      btn.addEventListener('click', () => openRestockModal(+btn.dataset.id, list.find(p => p.id === +btn.dataset.id)?.name));
    });
  }

  // ── Modals ───────────────────────────────────────────────────────────────────
  async function openProductModal(product, cats) {
    if (!cats) cats = await api.get('/categories');
    modalTitle.textContent = product ? 'Edit Product' : 'Add Product';

    modalBody.innerHTML = `
      <div class="form-group"><label>Name</label><input id="p-name" value="${esc(product?.name ?? '')}"/></div>
      <div class="form-row">
        <div class="form-group"><label>SKU</label><input id="p-sku" value="${esc(product?.sku ?? '')}" placeholder="ELEC-001"/></div>
        <div class="form-group"><label>Category</label>
          <select id="p-cat">
            <option value="">— None —</option>
            ${cats.map(c => `<option value="${c.id}" ${product?.category?.id === c.id ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}
          </select>
        </div>
      </div>
      <div class="form-row">
        <div class="form-group"><label>Price (₦)</label><input type="number" id="p-price" value="${product?.price ?? ''}" min="0" step="0.01"/></div>
        <div class="form-group"><label>Quantity</label><input type="number" id="p-qty" value="${product?.quantity ?? ''}" min="0"/></div>
      </div>
      <div class="form-group"><label>Low Stock Threshold</label><input type="number" id="p-threshold" value="${product?.lowStockThreshold ?? 10}" min="0"/></div>
      <div class="form-group"><label>Description</label><textarea id="p-desc">${esc(product?.description ?? '')}</textarea></div>
      <p class="error-text" id="p-err"></p>
      <div class="form-actions">
        <button class="btn-secondary" id="p-cancel">Cancel</button>
        <button class="btn-primary" id="p-save">${product ? 'Save Changes' : 'Create'}</button>
      </div>
    `;
    openModal();
    $('p-cancel').addEventListener('click', closeModal);
    $('p-save').addEventListener('click', async () => {
      const body = {
        name: $('p-name').value.trim(),
        sku:  $('p-sku').value.trim().toUpperCase(),
        price: parseFloat($('p-price').value),
        quantity: parseInt($('p-qty').value),
        lowStockThreshold: parseInt($('p-threshold').value) || 10,
        description: $('p-desc').value.trim(),
        category: $('p-cat').value ? { id: +$('p-cat').value } : null,
      };
      try {
        product ? await api.put(`/products/${product.id}`, body)
                : await api.post('/products', body);
        toast(product ? 'Product updated.' : 'Product created!');
        closeModal();
        products();
      } catch (e) { $('p-err').textContent = e.message; }
    });
  }

  function openCategoryModal(category) {
    modalTitle.textContent = category ? 'Edit Category' : 'New Category';
    modalBody.innerHTML = `
      <div class="form-group"><label>Name</label><input id="c-name" value="${esc(category?.name ?? '')}"/></div>
      <div class="form-group"><label>Description</label><textarea id="c-desc">${esc(category?.description ?? '')}</textarea></div>
      <p class="error-text" id="c-err"></p>
      <div class="form-actions">
        <button class="btn-secondary" id="c-cancel">Cancel</button>
        <button class="btn-primary" id="c-save">${category ? 'Save' : 'Create'}</button>
      </div>
    `;
    openModal();
    $('c-cancel').addEventListener('click', closeModal);
    $('c-save').addEventListener('click', async () => {
      const body = { name: $('c-name').value.trim(), description: $('c-desc').value.trim() };
      try {
        category ? await api.put(`/categories/${category.id}`, body)
                 : await api.post('/categories', body);
        toast(category ? 'Category updated.' : 'Category created!');
        closeModal();
        categories();
      } catch (e) { $('c-err').textContent = e.message; }
    });
  }

  function openRestockModal(id, name) {
    modalTitle.textContent = 'Restock Product';
    modalBody.innerHTML = `
      <p style="color:var(--dim);margin-bottom:14px">Add stock for <strong>${esc(name)}</strong></p>
      <div class="form-group"><label>Quantity to add</label><input type="number" id="r-qty" value="10" min="1"/></div>
      <p class="error-text" id="r-err"></p>
      <div class="form-actions">
        <button class="btn-secondary" id="r-cancel">Cancel</button>
        <button class="btn-primary" id="r-save">Add Stock</button>
      </div>
    `;
    openModal();
    $('r-cancel').addEventListener('click', closeModal);
    $('r-save').addEventListener('click', async () => {
      const delta = parseInt($('r-qty').value);
      if (!delta || delta < 1) { $('r-err').textContent = 'Enter a positive number.'; return; }
      try {
        await api.patch(`/products/${id}/stock?delta=${delta}`);
        toast(`Added ${delta} units.`);
        closeModal();
        lowstock();
      } catch (e) { $('r-err').textContent = e.message; }
    });
  }

  function confirmDelete(resource, name, path, refresh) {
    modalTitle.textContent = `Delete ${resource}`;
    modalBody.innerHTML = `
      <p style="color:var(--dim);margin-bottom:20px;line-height:1.6">Delete <strong>${esc(name)}</strong>? This cannot be undone.</p>
      <div class="form-actions">
        <button class="btn-secondary" id="d-cancel">Cancel</button>
        <button class="btn-danger" id="d-confirm">Delete</button>
      </div>
    `;
    openModal();
    $('d-cancel').addEventListener('click', closeModal);
    $('d-confirm').addEventListener('click', async () => {
      try {
        await api.delete(path);
        toast(`${resource} deleted.`, true);
        closeModal();
        refresh();
      } catch (e) { toast(e.message, true); closeModal(); }
    });
  }

  function openModal()  { modalOverlay.classList.remove('hidden'); }
  function closeModal() { modalOverlay.classList.add('hidden'); modalBody.innerHTML = ''; }

  // ── Toast ────────────────────────────────────────────────────────────────────
  function toast(msg, err = false) {
    const t = document.createElement('div');
    t.className = 'toast' + (err ? ' error' : '');
    t.textContent = msg;
    $('toasts').appendChild(t);
    setTimeout(() => t.remove(), 3200);
  }

  function esc(s = '') {
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }

  // ── Boot ─────────────────────────────────────────────────────────────────────
  navigate('dashboard');
})();
