-- Categories
INSERT INTO category (id, name, description) VALUES
  (1, 'Electronics',  'Gadgets, cables, and electronic components'),
  (2, 'Furniture',    'Office and home furniture'),
  (3, 'Stationery',   'Paper, pens, and office supplies'),
  (4, 'Networking',   'Routers, switches, and network hardware');

-- Products
INSERT INTO product (id, name, description, sku, price, quantity, low_stock_threshold, category_id, created_at) VALUES
  (1,  'MacBook Pro 14"',      'Apple M3 Pro laptop',              'ELEC-001', 299900, 12,  5,  1, CURRENT_TIMESTAMP),
  (2,  'USB-C Hub 7-in-1',     'Multiport adapter with HDMI 4K',   'ELEC-002', 4999,  80,  20, 1, CURRENT_TIMESTAMP),
  (3,  'Mechanical Keyboard',  'TKL, Cherry MX Brown switches',    'ELEC-003', 15000, 35,  10, 1, CURRENT_TIMESTAMP),
  (4,  'Standing Desk',        'Height-adjustable, 140x70cm',      'FURN-001', 89900, 8,   3,  2, CURRENT_TIMESTAMP),
  (5,  'Ergonomic Chair',      'Lumbar support, mesh back',        'FURN-002', 75000, 14,  5,  2, CURRENT_TIMESTAMP),
  (6,  'Monitor Arm',          'Dual VESA 75/100mm arm',           'FURN-003', 12500, 22,  8,  2, CURRENT_TIMESTAMP),
  (7,  'A4 Paper Ream',        '80gsm, 500 sheets',                'STAT-001', 800,   200, 50, 3, CURRENT_TIMESTAMP),
  (8,  'Whiteboard Markers',   'Assorted 8 colours, chisel tip',   'STAT-002', 1200,  3,   10, 3, CURRENT_TIMESTAMP),
  (9,  'TP-Link WiFi 6 Router','AX3000 dual-band router',          'NET-001',  35000, 17,  5,  4, CURRENT_TIMESTAMP),
  (10, 'Ethernet Cable Cat6',  '10m flat cable, snagless',         'NET-002',  2500,  60,  15, 4, CURRENT_TIMESTAMP);
